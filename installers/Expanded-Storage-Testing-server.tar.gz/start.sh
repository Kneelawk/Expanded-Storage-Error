#!/usr/bin/env bash

java -jar packwiz-installer-bootstrap.jar -g -s server https://raw.githubusercontent.com/Kneelawk/Expanded-Storage-Error/24-1.19.2-quilt-crash/pack.toml

java -jar quilt-server-launch.jar nogui

